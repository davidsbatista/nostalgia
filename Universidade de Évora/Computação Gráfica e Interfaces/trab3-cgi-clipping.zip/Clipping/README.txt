********************** Clipping de rectas ***************

Trabalho Realizado por:

Cl�udio Fernandes, n� 14103
Olivier Rodrigues, n� 14195
Nuno Morgadinho, n� 13591



