/*
   implementation of all the arithmetic functions on matrices
   such as add(), subtract(), etc, declared in matrix.h
*/

#include "matrix.h"

/*
  adds two matrices and stores the resultant matrix in *result
  assumes that all the matrices are of same order i.e. 'morder'

  algorithm:
  
  1. for i = 1 to rows in matrices (order is same of al matrices)
     a. for j = 1 to columns in matrices (matrices are two dimensional arrays)
        1. compute [i][j]th element of result by adding [i][j]th elements
	   of matrix1 and matrix2
*/

void add(const int *mat1, const int *mat2, int *result, order morder) {
  int i, j, sub;

  /* array indices start with 0 in C ;-) */
  for (i = 0; i < morder.rows; i++)
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      result[sub] = mat1[sub] + mat2[sub];
    }
}

/* 
   subtracts second matrix from first and stores the resultant matrix
   in *result matrix, assumes that all matrices are of equal order 'morder'

   algorithm:
   1. for i = 1 to rows in matrices
      a. for j = 1 to columns in matrices
         1. compute [i][j]th element of *result by subtracting [i][j]th
	    element of matrix2 from [i][j]th element of matrix1
*/

void subtract(const int *mat1, const int *mat2, int *result, order morder) {
  int i, j;
  int sub;

  for (i = 0; i < morder.rows; i++)
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      result[sub] = mat1[sub] - mat2[sub];
    }
}

/*
  multiplies two matrices and stores the resultant matrix in *result
  the two matrices must be subject to multiplication i.e. matrix1's columns
  should be equal to the matrix2's rows. if a matrix of order 2 x 3 is 
  multiplied with a matrix of 3 x 2 order, the resultant matrix is of 2 x 2
  order i.e. matrix1's rows x matrix2's columns

  algorithm:
  in order to multiply two matrices you need to first understand how to
  multiply a row and column matrix.
  suppose, matrix1 is a 1 x 3 matrix and matrix2 is a 3 x 1 matrix
  then the resultant matrix after multiplication will be of order 1 x 1
  this only element is computer as follows:

    m1[1][1] * m2[1][1]
  + m1[1][2] * m2[2][1]
  + m1[1][3] * m2[3][1]

  as you can see in complete calculation row of m1 is constant i.e. 1
  so is column of m2 is i.e. 1 only variation that is there is in the
  m1's columns and m2's rows. so [2][1]th element of the product matrix of 
  above two matrix1 and matrix2 is computed as follows

    m1[2][1] * m2[1][1]
  + m1[2][2] * m2[2][1]
  + m1[2][3] * m2[3][1]

  thus we have to repeat these steps 4 times to compute the product of
  two matrices as it is a 2 x 2 matrix

  1. for i = 1 to rows of first matrix
     a. for j = 1 to columns of second matrix
        1. compute [i][j]th element of product by computing product of
	   [i]th row of matrix1 and [j]th column of matrix2 as described
	   above

*/

void multiply(const int *mat1, order ord1, const int *mat2, order ord2,
	      int *result) {
  int i, j; /* array indices */
  int k;
  int element; /* product of rows and cols will be summed up in this */

  /* check if the two matrices can be multiplied or not */
  if (ord1.cols != ord2.rows) /* if not exit */
    return;

  for (i = 0; i < ord1.rows; i++)
    for (j = 0; j < ord2.cols; j++) {
      element = 0;
      for (k = 0; k < ord1.cols; k++)
	element += mat1[ord1.cols * i + k] * mat2[ord2.cols * k + j];

      result[ord2.cols * i + j] = element;
    }
}
