/* implementation of the matrix input output functions declared in matrix.h */

#include <stdio.h>
#include "matrix.h"

/*
  lets the user input a matrix through keyboard

  algorithm:
  1. for i = 1 to rows in matrix
     a. for j = 1 to columns in matrix
        read value in matrix[i][j]
*/

void input(int *matrix, order morder) {
  int i, j, sub;

  for (i = 0; i < morder.rows; i++)
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      printf("enter value for matrix[%d][%d]: ", i + 1, j + 1);
      scanf("%d", matrix + sub);
    }
}

/*
  outputs the matrix on screen i.e. prints

  algorithm:
  1. for i = 1 to rows in matrix
     a. for j = 1 to columns in matrix
        1. print matrix[i][j]
*/

void output(const int *matrix, order morder) {
  int i, j, sub;

  for (i = 0; i < morder.rows; i++) {
    for (j = 0; j < morder.cols; j++) {
      sub = morder.cols * i + j;
      printf("%d\t", matrix[sub]);
    }
    printf("\n");
  }
}
