/* header file for the matrix library */

#ifndef MATRIX_H
#define MATRIX_H

typedef struct tagORDER { /* order of matrix */
  int rows; /* rows in matrix */
  int cols; /* cols in matrix */
} order;

/* function declarations */

/* takes a matrix input from keyboard */
void input(int *matrix, order morder);

/* outputs a matrix i. e. prints on screen */
void output(const int *matrix, order morder);

/* adds two matrices and stores the answer into a third one */
/* mat1 and mat2 are two matrices, morder is order of matrices */
/* and result is the resultant matrix after addition */
void add(const int *mat1, const int *mat2, int *result, order morder);

/* subtracts *mat2 from *mat1 and store the result in *result */
void subtract(const int *mat1, const int *mat2, int *result, order morder);

/* computes the transpose of a given matrix */
/* order of a matrix is also changed after transposing */
void transpose(int *matrix, order *morder);

/* multiplies the two matrices *mat1 and *mat2 */
/* and stores the resultant matrix in *result */
/* it assumes *result is large enough i.e. of [ord1.rows][ord2.cols] size */
void multiply(const int *mat1, order ord1, const int *mat2, order ord2, 
	      int *result);

#endif /* MATRIX_H */
