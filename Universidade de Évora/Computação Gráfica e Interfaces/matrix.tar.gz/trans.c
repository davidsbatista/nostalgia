/* implementation of the transpose() function declared in matrix.h */

#include <stdlib.h>
#include "matrix.h"

/*
  computes transpose of a matrix.
  order of a matrix is also changed if matrix is not a square matrix

  transposing means intechanging rows and columns of a matrix
  so that [1][3]th element of a matrix will be the [3][1]th element when
  transposed

  algorithm:
  1. for i = 1 to rows in matrix1
     a. for j = 1 to columns in matrix1
        1. matrix2[j][i] = matrix1[i][j]
  2. interchange the order of matrix i.e. exchange the rows and cols in morder
*/

void transpose(int *matrix, order *morder) {
  int *trans; /* pointer to hold the dynamically allocated matrix */
  int i, j; /* matrix subscripts */
  order torder; /* order of the transposed matrix */
  int sub;

  /* first compute the order of the transposed matrix */
  /* i. e. by interchanging the values of rows and cols */
  torder.rows = morder->cols;
  torder.cols = morder->rows;

  trans = (int *)malloc(sizeof(int) * torder.rows * torder.cols);
  if (! trans)
    return;

  /* compute the transpose of matrix and store it in trans */
  for (i = 0; i < morder->rows; i++)
    for (j = 0; j < morder->cols; j++)
      trans[morder->rows * j + i] = matrix[morder->cols * i + j];
  
  /* adjust the order of original matrix */
  *morder = torder;

  /* now copy the transposed matrix into original */
  for (i = 0; i < morder->rows; i++)
    for (j = 0; j < morder->cols; j++) {
      sub = morder->cols * i + j;
      matrix[sub] = trans[sub];
    }

  /* free the memory allocated */
  free(trans);
}
