/*
  test suit for the subtract() function declared in matrix.h which subtracts
  the second matrix from the first matrix and stores the result in third
*/

#include <stdio.h>
#include "matrix.h"

int main() {
  const order morder = { 2, 3 }; /* order of the matrices */

  /* three 2 x 3 matrices */
  int mat1[morder.rows][morder.cols];
  int mat2[morder.rows][morder.cols];
  int result[morder.rows][morder.cols];

  input(&mat1[0][0], morder);
  output(&mat1[0][0], morder);

  input(&mat2[0][0], morder);
  output(&mat2[0][0], morder);

  printf("subtracting matrices...\n");
  subtract(&mat1[0][0], &mat2[0][0], &result[0][0], morder);
  output(&result[0][0], morder);

  return 0;
}
